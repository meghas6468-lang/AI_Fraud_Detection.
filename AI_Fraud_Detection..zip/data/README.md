# Dataset

Place the supplied `creditcard.csv` in this directory to retrain the model. It should contain `Time`, `V1`–`V28`, `Amount`, and `Class`.

The dataset used for this portfolio build is the public Credit Card Fraud Detection dataset (ULB/Kaggle). The repository does not redistribute the dataset.
