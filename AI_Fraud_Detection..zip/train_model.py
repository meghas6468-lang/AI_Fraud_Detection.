
"""Reproducible training script for the fraud autoencoder."""
import os, json, joblib, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import precision_score, recall_score, f1_score, average_precision_score, roc_auc_score, confusion_matrix

ROOT=os.path.dirname(os.path.abspath(__file__))
CSV=os.path.join(ROOT,"data","creditcard.csv")
df=pd.read_csv(CSV)
features=["Time"]+[f"V{i}" for i in range(1,29)]+["Amount"]
X=df[features]; y=df["Class"].astype(int)
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.2,stratify=y,random_state=42)
normal=X_train[y_train==0]
scaler=StandardScaler(); Xn=scaler.fit_transform(normal); Xt=scaler.transform(X_test)
model=MLPRegressor(hidden_layer_sizes=(32,16,32),activation="relu",solver="adam",
    batch_size=512,learning_rate_init=1e-3,max_iter=25,early_stopping=True,
    validation_fraction=.1,n_iter_no_change=3,random_state=42)
model.fit(Xn,Xn)
train_err=np.mean((Xn-model.predict(Xn))**2,axis=1)
test_err=np.mean((Xt-model.predict(Xt))**2,axis=1)
threshold=float(np.percentile(train_err,99.5)); pred=(test_err>threshold).astype(int)
metrics={"threshold":threshold,"precision":precision_score(y_test,pred,zero_division=0),
"recall":recall_score(y_test,pred,zero_division=0),"f1":f1_score(y_test,pred,zero_division=0),
"pr_auc":average_precision_score(y_test,test_err),"roc_auc":roc_auc_score(y_test,test_err),
"confusion_matrix":confusion_matrix(y_test,pred).tolist(),"normal_train":len(normal),
"test_size":len(y_test),"fraud_test":int(y_test.sum()),"normal_test":int((y_test==0).sum()),
"iterations":model.n_iter_,"training_loss":float(model.loss_)}
os.makedirs(os.path.join(ROOT,"models"),exist_ok=True); os.makedirs(os.path.join(ROOT,"results"),exist_ok=True)
joblib.dump(model,os.path.join(ROOT,"models","fraud_autoencoder.joblib"),compress=3)
joblib.dump(scaler,os.path.join(ROOT,"models","scaler.joblib"))
with open(os.path.join(ROOT,"results","metrics.json"),"w") as f: json.dump(metrics,f,indent=2)
print(json.dumps(metrics,indent=2))
