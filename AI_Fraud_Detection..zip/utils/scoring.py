
import numpy as np

def reconstruction_error(model, X):
    pred = model.predict(X)
    return np.mean((X - pred) ** 2, axis=1)

def risk_score(error, threshold):
    """Maps reconstruction error to a 0-100 anomaly risk score."""
    error = float(error)
    threshold = max(float(threshold), 1e-12)
    score = 50.0 * (error / threshold) if error < threshold else 50.0 + 50.0 * min((error / threshold - 1.0) / 2.0, 1.0)
    return round(float(np.clip(score, 0, 100)), 2)

def label_from_error(error, threshold):
    return "Potential Fraud" if float(error) > float(threshold) else "Likely Legitimate"
