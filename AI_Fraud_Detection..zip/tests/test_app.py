
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import app
def test_health():
    client=app.test_client()
    r=client.get("/health")
    assert r.status_code==200
    assert r.json["status"]=="ok"
