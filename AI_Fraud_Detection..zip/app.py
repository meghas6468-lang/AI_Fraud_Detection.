
from flask import Flask, render_template, request, jsonify
import os, json, joblib, pandas as pd
from utils.preprocessing import FEATURE_COLUMNS, validate_features
from utils.scoring import reconstruction_error, risk_score, label_from_error

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL = joblib.load(os.path.join(BASE, "models", "fraud_autoencoder.joblib"))
SCALER = joblib.load(os.path.join(BASE, "models", "scaler.joblib"))
with open(os.path.join(BASE, "results", "metrics.json"), encoding="utf-8") as f:
    METRICS = json.load(f)

app = Flask(__name__)

@app.get("/")
def home():
    return render_template("index.html", feature_columns=FEATURE_COLUMNS, metrics=METRICS)

@app.get("/dashboard")
def dashboard():
    return render_template("dashboard.html", metrics=METRICS)

@app.post("/predict")
def predict():
    try:
        if "file" in request.files and request.files["file"].filename:
            df = pd.read_csv(request.files["file"])
            X = validate_features(df)
            Xs = SCALER.transform(X)
            errors = reconstruction_error(MODEL, Xs)
            rows = []
            for i, err in enumerate(errors):
                rows.append({
                    "row": i + 1,
                    "error": round(float(err), 6),
                    "risk": risk_score(err, METRICS["threshold"]),
                    "label": label_from_error(err, METRICS["threshold"])
                })
            fraud_count = sum(r["label"] == "Potential Fraud" for r in rows)
            return render_template("result.html", rows=rows, total=len(rows), fraud_count=fraud_count)
        values = [float(request.form[c]) for c in FEATURE_COLUMNS]
        X = SCALER.transform([values])
        err = reconstruction_error(MODEL, X)[0]
        label = label_from_error(err, METRICS["threshold"])
        return render_template("result.html",
            rows=[{"row":1,"error":round(float(err),6),"risk":risk_score(err,METRICS["threshold"]),"label":label}],
            total=1, fraud_count=int(label=="Potential Fraud"))
    except Exception as e:
        return render_template("index.html", feature_columns=FEATURE_COLUMNS, metrics=METRICS, error=str(e)), 400

@app.post("/api/predict")
def api_predict():
    payload = request.get_json(force=True)
    values = [float(payload[c]) for c in FEATURE_COLUMNS]
    X = SCALER.transform([values])
    err = reconstruction_error(MODEL, X)[0]
    return jsonify({
        "prediction": label_from_error(err, METRICS["threshold"]),
        "risk_score": risk_score(err, METRICS["threshold"]),
        "reconstruction_error": round(float(err), 6),
        "threshold": METRICS["threshold"]
    })

@app.get("/health")
def health():
    return jsonify({"status":"ok","model":"loaded"})

if __name__ == "__main__":
    app.run(debug=True)
