# AI-Based Credit Card Fraud Detection System

A portfolio-ready fraud detection web application using an autoencoder-style neural network for anomaly detection.

## What is implemented
- Trained reconstruction-based anomaly detector
- Leakage-safe split: model trained only on normal transactions
- Reconstruction-error threshold
- Fraud risk score
- Flask web interface
- Single-transaction prediction
- CSV batch prediction
- Evaluation dashboard
- Saved model and scaler
- Reproducible training script
- Automated health test

## Dataset
This build was trained using the supplied public Credit Card Fraud Detection dataset. The dataset contains 284,807 transactions and 492 fraud cases. The dataset itself is not redistributed in this repository.

Place `creditcard.csv` at `data/creditcard.csv` if retraining.

## Model
Input features: `Time`, `V1`–`V28`, `Amount`.

The model is an `MLPRegressor` reconstruction network with hidden layers `(32, 16, 32)`. It learns the structure of normal transactions. A high reconstruction error is treated as an anomaly.

The fraud threshold is the 99.5th percentile of reconstruction error on the normal training set.

## Evaluation
This trained build produced:
- PR-AUC: 0.6752
- ROC-AUC: 0.9479
- Precision: 0.2265
- Recall: 0.8367
- F1: 0.3565

These metrics are test-set measurements and should not be interpreted as guaranteed real-world fraud-detection performance.

## Run
```bash
python -m venv venv
# Windows:
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`.

## Retrain
Put the dataset at `data/creditcard.csv`, then run:
```bash
python train_model.py
```

## API
POST JSON to `/api/predict` containing `Time`, `V1`–`V28`, and `Amount`.

## Attribution
This project was developed as an independent portfolio implementation inspired by publicly available anomaly-detection approaches, including the Curiousily Credit Card Fraud Detection using Autoencoders in Keras tutorial. Original inspiration: https://github.com/curiousily/Credit-Card-Fraud-Detection-using-Autoencoders-in-Keras

Do not represent the upstream tutorial, its code, or its pretrained model as original work. This repository's training pipeline, Flask application, UI, evaluation workflow, and documentation are separate implementations.
