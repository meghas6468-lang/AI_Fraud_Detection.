# Training Summary

Dataset rows: 284,807
Fraud rows: 492
Normal rows: 284,315
Test size: 56,962
Normal training rows: 227,451

Model: MLP reconstruction autoencoder
Architecture: 30 -> 32 -> 16 -> 32 -> 30
Training target: normal transactions only
Threshold: 99.5th percentile of normal-training reconstruction error

## Test metrics

| Metric | Value |
|---|---:|
| PR-AUC | 0.6752 |
| ROC-AUC | 0.9479 |
| Precision | 0.2265 |
| Recall | 0.8367 |
| F1 | 0.3565 |

Confusion matrix:
`[[56584, 280], [16, 82]]`
